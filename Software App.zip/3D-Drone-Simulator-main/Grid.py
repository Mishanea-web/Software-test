#gridbuilder
'''
grids are used for floors of 3d scenes
'''


class Grid:

	def __init__(self):

	def generate_nodes:

	def generate_points:

